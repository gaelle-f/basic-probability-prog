Files for Homework 3.

20news-18828: contains the training instances for the NB classifier
dev-set: contains 2000 development files on which accuracy can be checked during development
dev_keys.txt: file containing the true labels for all dev files
