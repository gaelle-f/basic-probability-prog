Files for Homework 3.

small-20news-18828: contains the training instances for the NB classifier
small-dev-set: contains the testing test (for which we are making predictions)